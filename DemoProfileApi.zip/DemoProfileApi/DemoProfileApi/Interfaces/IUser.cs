﻿using DemoProfileApi.Models;

namespace DemoProfileApi.Interfaces
{
    public interface IUser
    {
        Task<ProfileResponse> GetUserDetails(string Email);
    }
}
