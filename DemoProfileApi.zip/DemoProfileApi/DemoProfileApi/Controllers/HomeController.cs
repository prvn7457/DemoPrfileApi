﻿using DemoProfileApi.Interfaces;
using DemoProfileApi.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Diagnostics;
using System.Text;

namespace DemoProfileApi.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private readonly IUser _user;
        public HomeController(ILogger<HomeController> logger,IUser user)
        {
           _user = user;
            _logger = logger;
        }

        public IActionResult Index()
        {
           

       

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
       public async Task<IActionResult> Profile(string Email)
        {
           ProfileResponse resObj = new ProfileResponse();

            resObj = await _user.GetUserDetails(Email);
            if (resObj.status == false)
            {
                ViewBag.Message = resObj.message;
            }
            if (resObj.profile.reg_status == "P")
            {
                ViewBag.Message = "You are already registered, please login";
            }
            if (resObj.profile.reg_status == "F")
            {
                ViewBag.Message = "You are already registered, please login";
            }
            if(resObj.profile.reg_status == "")
            {
                ViewBag.Message = "Please Update your status into Database";
            }
            return View("Index", resObj);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}






