﻿namespace DemoProfileApi.Models
{
    public class ProfileResponse
    {
        public string d { get; set; }
        public bool status { get; set; }
        public string message { get; set; }
        public Profile profile { get; set; }
    }
    public class Profile
    {
        public string Contact_ID { get; set; }
        public string Email { get; set; }
        public string reg_status  { get; set; }
    }
}
