﻿namespace DemoProfileApi.Models
{
    public class ProfileModel
    {
        public string request_apikey { get; set; }
        public string login_page_url { get; set; }
        public string txtEmail { get; set; }
    }
}
