﻿using DemoProfileApi.Interfaces;
using DemoProfileApi.Models;
using Newtonsoft.Json;
using System.Text;

namespace DemoProfileApi.Repository.Services
{
    public class ProfileService : IUser
    {
        

        public async Task <ProfileResponse> GetUserDetails(string Email)
        {
           var resposne = new ProfileResponse();
           ProfileModel model = new ProfileModel();    
            model.txtEmail = Email;  
            model.request_apikey = "vk_test_sjf9234dfui343i4ui34ui34u3i";
            model.login_page_url = "https://www.cpesite.com/blahblah.aspx";
            string apiBaseUrl = "https://www.thedemoforum.com/tdf/Meetup/API.aspx";
            using (HttpClient client = new HttpClient())
            {
                StringContent content = new StringContent(JsonConvert.SerializeObject(model), Encoding.UTF8, "application/json");
                string endpoint = apiBaseUrl + "/Profile";
                using (var Response = await client.PostAsync(endpoint, content))
                {
                    if (Response.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        var res = await Response.Content.ReadAsStringAsync();

                         resposne = JsonConvert.DeserializeObject<ProfileResponse>(res);
                        resposne = JsonConvert.DeserializeObject<ProfileResponse>(resposne.d);
                       
                    }

                }
            }
            return resposne;
        }
    }
}
